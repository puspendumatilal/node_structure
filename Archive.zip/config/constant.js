constant ={
  passwordEncryptionKey: "askgklklass",
  connection_pool: {},
  dbconn: {},
  master_database:"master_db",
  child_database1:"child_db_1",
  child_database2:"child_db_2"
}
module.exports = constant;
