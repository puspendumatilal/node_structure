 db = {
  master_db: {
    host: 'localhost',
    database: 'master_customer',
  },
  child_db_1: {
    host: 'localhost',
    database: 'child1',
  },
  child_db_2: {
    host: 'localhost',
    database: 'child2',
  },
}
module.exports = db;
